import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function uid(prefix = "id"): string {
  const rand =
    typeof crypto !== "undefined" && crypto.randomUUID
      ? crypto.randomUUID()
      : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  return `${prefix}-${rand}`;
}

export function clampText(value: string, max: number): string {
  if (value.length <= max) return value;
  return value.slice(0, max);
}

export function formatClock(ts: number, language: "pt" | "en"): string {
  try {
    return new Date(ts).toLocaleTimeString(language === "pt" ? "pt-PT" : "en-US", {
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return "";
  }
}

export function formatDateTime(ts: number, language: "pt" | "en"): string {
  try {
    return new Date(ts).toLocaleString(language === "pt" ? "pt-PT" : "en-US", {
      day: "2-digit",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return "";
  }
}

export function titleFromText(text: string): string {
  const cleaned = text.replace(/\s+/g, " ").trim();
  if (!cleaned) return "AEGIS";
  return cleaned.length > 48 ? `${cleaned.slice(0, 48).trim()}…` : cleaned;
}
