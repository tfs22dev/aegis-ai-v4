import { localeTag, t } from "./i18n";
import type { Language } from "./types";

type SpeechRecCtor = new () => SpeechRecognitionLike;

interface SpeechRecognitionLike {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((ev: { results: ArrayLike<{ 0: { transcript: string } }> }) => void) | null;
  onerror: ((ev: { error?: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

function recognitionCtor(): SpeechRecCtor | null {
  if (typeof window === "undefined") return null;
  const w = window as Window & {
    SpeechRecognition?: SpeechRecCtor;
    webkitSpeechRecognition?: SpeechRecCtor;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function canSpeak(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

export function canListen(): boolean {
  return recognitionCtor() !== null;
}

export function stopSpeaking(): void {
  if (!canSpeak()) return;
  window.speechSynthesis.cancel();
}

export function speak(text: string, language: Language): { ok: true } | { ok: false; message: string } {
  if (!canSpeak()) return { ok: false, message: t(language).errorSpeech };
  const clean = text
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/[`*_#>[\]()]/g, " ")
    .replace(/https?:\/\/\S+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 1400);
  if (!clean) return { ok: true };
  stopSpeaking();
  const utter = new SpeechSynthesisUtterance(clean);
  utter.lang = localeTag(language);
  utter.rate = 1.02;
  const voices = window.speechSynthesis.getVoices();
  const match = voices.find((v) => v.lang.toLowerCase().startsWith(language === "pt" ? "pt" : "en"));
  if (match) utter.voice = match;
  window.speechSynthesis.speak(utter);
  return { ok: true };
}

export function startListening(
  language: Language,
  onText: (transcript: string) => void,
  onEnd: () => void,
  onError: (message: string) => void,
): () => void {
  const Ctor = recognitionCtor();
  if (!Ctor) {
    onError(t(language).errorSpeech);
    onEnd();
    return () => {};
  }
  const rec = new Ctor();
  rec.lang = localeTag(language);
  rec.interimResults = false;
  rec.continuous = false;
  rec.onresult = (ev) => {
    const first = ev.results[0];
    const transcript = first?.[0]?.transcript ?? "";
    if (transcript.trim()) onText(transcript.trim());
  };
  rec.onerror = () => {
    onError(t(language).errorSpeechStart);
  };
  rec.onend = () => onEnd();
  try {
    rec.start();
  } catch {
    onError(t(language).errorSpeechStart);
    onEnd();
    return () => {};
  }
  return () => {
    try {
      rec.abort();
    } catch {
      /* ignore */
    }
  };
}
