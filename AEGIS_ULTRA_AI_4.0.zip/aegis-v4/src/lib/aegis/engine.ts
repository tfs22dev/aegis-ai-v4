import { calculate, formatNumber, looksLikeMath } from "./calculator";
import { t } from "./i18n";
import { isOnline } from "./net";
import { extractImageQuery, isImageQuery, isTimeQuery, searchImages, searchWikipedia } from "./research";
import { completeChat, instantAnswer } from "./server";
import type { ChatMessage, Language, LongTermMemory, QueryResult, ResponseMode, Source } from "./types";
import { LIMITS } from "./types";

const GREETING_RE =
  /^(olá|ola|oi|bom dia|boa tarde|boa noite|viva|saudações|saudacoes|hello|hi|hey|good morning|good afternoon|good evening|greetings|how are you|how('s| is) it going|what'?s up|como estás|como estas|como tem passado|tudo bem|seja bem[- ]?vind[oa]|bem[- ]?vind[oa]|é um prazer|muito gosto|espero que esteja tudo bem)[\s!?.]*$/i;

function isGreeting(text: string): boolean {
  const cleaned = text.trim().replace(/[!?.]+$/g, "").trim();
  if (cleaned.length > 80) return false;
  return GREETING_RE.test(cleaned) || /seja muito bem[- ]?vindo/i.test(cleaned);
}

function memoryBlock(memory: LongTermMemory, language: Language): string {
  const lines: string[] = [];
  if (memory.userName) lines.push(`${language === "pt" ? "Nome" : "Name"}: ${memory.userName}`);
  if (memory.notes.length) lines.push(memory.notes.map((n) => `- ${n}`).join("\n"));
  if (memory.recentTopics.length) {
    lines.push(
      (language === "pt" ? "Tópicos recentes: " : "Recent topics: ") + memory.recentTopics.join("; "),
    );
  }
  return lines.join("\n").slice(0, 1800);
}

function mergeSources(...lists: (Source[] | undefined)[]): Source[] {
  const seen = new Set<string>();
  const out: Source[] = [];
  for (const list of lists) {
    if (!list) continue;
    for (const s of list) {
      if (seen.has(s.url)) continue;
      seen.add(s.url);
      out.push(s);
    }
  }
  return out.slice(0, 6);
}

async function tryModel(
  query: string,
  language: Language,
  memory: LongTermMemory,
  history: ChatMessage[],
  research?: string,
  mode: ResponseMode = "balanced",
): Promise<string | null> {
  const contextLimit = mode === "fast" ? 4 : mode === "deep" ? 14 : LIMITS.contextMessages;
  const messages = history
    .filter((m) => m.role === "user" || m.role === "assistant")
    .slice(-contextLimit)
    .map((m) => ({ role: m.role as "user" | "assistant", content: m.content.slice(0, 4000) }));
  if (!messages.length || messages[messages.length - 1]?.content !== query) {
    messages.push({ role: "user", content: query.slice(0, LIMITS.message) });
  }
  try {
    const result = await completeChat({
      data: {
        language,
        memory: memoryBlock(memory, language),
        research,
        messages,
        mode,
      },
    });
    if (result.ok) return result.text;
    return null;
  } catch (err) {
    console.error("completeChat", err);
    return null;
  }
}

async function tryInstant(query: string): Promise<{ text: string; sources: Source[] } | null> {
  try {
    const result = await instantAnswer({ data: { query: query.slice(0, 200) } });
    if (result.ok) return { text: result.text, sources: result.sources };
    return null;
  } catch (err) {
    console.error("instantAnswer", err);
    return null;
  }
}

export async function processQuery(input: {
  text: string;
  language: Language;
  memory: LongTermMemory;
  history: ChatMessage[];
  mode?: ResponseMode;
}): Promise<QueryResult> {
  const { language, memory, history } = input;
  const mode = input.mode ?? "balanced";
  const text = input.text.trim().slice(0, LIMITS.message);
  const ui = t(language);

  if (!text) {
    return { text: ui.errorEmpty, tool: "local", error: true };
  }

  if (isGreeting(text)) {
    const name = memory.userName || "";
    return {
      tool: "greeting",
      text: ui.greetingReply(name),
    };
  }

  if (looksLikeMath(text)) {
    const result = calculate(text);
    if (!result.ok) {
      return { text: ui.errorCalc, tool: "calculator", error: true };
    }
    return {
      tool: "calculator",
      text: `**${ui.calcResult}**\n\n\`${result.expression} = ${formatNumber(result.value, language)}\``,
    };
  }

  if (isTimeQuery(text)) {
    const when = new Date().toLocaleString(language === "pt" ? "pt-PT" : "en-US", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
    return { tool: "time", text: ui.timeAnswer(when) };
  }

  if (isImageQuery(text)) {
    if (!isOnline()) return { text: ui.errorNetwork, tool: "images", error: true };
    const q = extractImageQuery(text);
    const images = await searchImages(q);
    if (!images.length) {
      return { text: ui.noImages, tool: "images", error: true };
    }
    const list = images
      .map((img) => `- [${img.title}](${img.pageUrl})`)
      .join("\n");
    return {
      tool: "images",
      text: `**${ui.imagesLabel}** — ${q}\n\n${list}`,
      images,
      sources: images.map((img) => ({ title: img.title, url: img.pageUrl })),
    };
  }

  if (!isOnline()) {
    return { text: ui.errorNetwork, tool: "local", error: true };
  }

  // Fast mode: prefer instant answer, skip or light Wikipedia
  // Deep mode: fuller research from free public sources
  const doWiki = mode !== "fast";
  const researchLimit = mode === "fast" ? 1200 : mode === "deep" ? 5200 : 3800;

  const [wiki, ddg] = await Promise.all([
    doWiki
      ? searchWikipedia(text, language).catch((err) => {
          console.error("wikipedia", err);
          return null;
        })
      : Promise.resolve(null),
    tryInstant(text),
  ]);

  const researchParts = [wiki?.text, ddg?.text].filter(Boolean).join("\n\n").slice(0, researchLimit);
  const sources = mergeSources(wiki?.sources, ddg?.sources);

  const modeled = await tryModel(text, language, memory, history, researchParts || undefined, mode);
  if (modeled) {
    return {
      tool: researchParts ? "hybrid" : "model",
      text: modeled,
      sources,
    };
  }

  if (wiki) {
    return {
      tool: "wikipedia",
      text: `${wiki.text}\n\n_${ui.wikiFallback}_`,
      sources,
    };
  }

  if (ddg) {
    return {
      tool: "search",
      text: ddg.text,
      sources,
    };
  }

  // Fallback for non-Wikipedia questions: encourage free public knowledge style reply
  return {
    tool: "local",
    text:
      language === "pt"
        ? "Não encontrei uma fonte pública fiável (Wikipedia/DuckDuckGo) para este pedido. Posso tentar reformular a pergunta ou usar o modo profundo para pesquisar mais a fundo com fontes gratuitas."
        : "I could not find a reliable public source (Wikipedia/DuckDuckGo) for this request. You can rephrase the question or switch to Deep mode for broader free-source research.",
    error: true,
  };
}
