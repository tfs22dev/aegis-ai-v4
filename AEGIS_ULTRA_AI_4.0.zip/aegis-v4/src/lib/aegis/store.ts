import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { uid } from "@/lib/utils";
import { t } from "./i18n";
import type {
  ChatMessage,
  Conversation,
  Feedback,
  Language,
  LongTermMemory,
  PanelId,
  ResponseMode,
  Theme,
} from "./types";
import { LIMITS, STORAGE_KEYS } from "./types";

export interface AegisState {
  language: Language;
  theme: Theme;
  animations: boolean;
  voiceEnabled: boolean;
  autoSpeak: boolean;
  responseMode: ResponseMode;
  userName: string;
  verified: boolean;
  panel: PanelId | null;
  sidebarOpen: boolean;
  isProcessing: boolean;
  modelAvailable: boolean | null;
  conversations: Conversation[];
  currentId: string | null;
  memory: LongTermMemory;
  feedback: Record<string, Feedback>;
  hydrated: boolean;

  markHydrated: () => void;
  setLanguage: (language: Language) => void;
  setTheme: (theme: Theme) => void;
  setAnimations: (value: boolean) => void;
  setVoiceEnabled: (value: boolean) => void;
  setAutoSpeak: (value: boolean) => void;
  setResponseMode: (mode: ResponseMode) => void;
  setPanel: (panel: PanelId | null) => void;
  setSidebarOpen: (open: boolean) => void;
  setProcessing: (value: boolean) => void;
  setModelAvailable: (value: boolean) => void;
  verify: (name: string) => void;
  newChat: () => void;
  openConversation: (id: string) => void;
  deleteConversation: (id: string) => void;
  clearHistory: () => void;
  addMemoryNote: (note: string) => void;
  removeMemoryNote: (index: number) => void;
  clearMemory: () => void;
  clearAllData: () => void;
  setFeedback: (id: string, value: Feedback) => void;
  appendMessage: (message: ChatMessage) => void;
  removeLastAssistant: () => ChatMessage | null;
  rememberTopic: (topic: string) => void;
}

function greeting(name: string, language: Language): ChatMessage {
  return {
    id: uid("m"),
    role: "assistant",
    content: t(language).greeting(name),
    createdAt: Date.now(),
    tool: "local",
  };
}

function blankConversation(name: string, language: Language): Conversation {
  const now = Date.now();
  return {
    id: uid("c"),
    title: language === "pt" ? "Nova conversa" : "New chat",
    createdAt: now,
    updatedAt: now,
    messages: [greeting(name, language)],
  };
}

function capConversations(list: Conversation[]): Conversation[] {
  return list
    .slice()
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .slice(0, LIMITS.conversations);
}

const emptyMemory: LongTermMemory = { userName: "", notes: [], recentTopics: [] };

export const useAegisStore = create<AegisState>()(
  persist(
    (set, get) => ({
      language: "pt",
      theme: "dark",
      animations: true,
      voiceEnabled: true,
      autoSpeak: false,
      responseMode: "balanced",
      userName: "",
      verified: false,
      panel: null,
      sidebarOpen: false,
      isProcessing: false,
      modelAvailable: null,
      conversations: [],
      currentId: null,
      memory: emptyMemory,
      feedback: {},
      hydrated: false,

      markHydrated: () => {
        let verified = false;
        try {
          verified = sessionStorage.getItem(STORAGE_KEYS.session) === "ok";
        } catch {
          verified = false;
        }
        const { userName, conversations, language } = get();
        if (verified && userName && conversations.length === 0) {
          const conv = blankConversation(userName, language);
          set({
            verified: true,
            hydrated: true,
            conversations: [conv],
            currentId: conv.id,
            memory: { ...get().memory, userName },
          });
          return;
        }
        set({ verified, hydrated: true });
      },

      setLanguage: (language) => {
        const { memory } = get();
        set({ language, memory: { ...memory } });
      },
      setTheme: (theme) => set({ theme }),
      setAnimations: (animations) => set({ animations }),
      setVoiceEnabled: (voiceEnabled) => set({ voiceEnabled, autoSpeak: voiceEnabled ? get().autoSpeak : false }),
      setAutoSpeak: (autoSpeak) => set({ autoSpeak }),
      setResponseMode: (responseMode) => set({ responseMode }),
      setPanel: (panel) => set({ panel, sidebarOpen: false }),
      setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),
      setProcessing: (isProcessing) => set({ isProcessing }),
      setModelAvailable: (modelAvailable) => set({ modelAvailable }),

      verify: (name) => {
        const userName = name.trim().slice(0, 40);
        try {
          sessionStorage.setItem(STORAGE_KEYS.session, "ok");
        } catch {
          /* ignore quota */
        }
        const { conversations, language, memory } = get();
        if (conversations.length === 0) {
          const conv = blankConversation(userName, language);
          set({
            userName,
            verified: true,
            conversations: [conv],
            currentId: conv.id,
            memory: { ...memory, userName },
          });
          return;
        }
        set({
          userName,
          verified: true,
          memory: { ...memory, userName },
        });
      },

      newChat: () => {
        const { userName, language, conversations } = get();
        const conv = blankConversation(userName || "AEGIS", language);
        set({
          conversations: capConversations([conv, ...conversations]),
          currentId: conv.id,
          panel: null,
          sidebarOpen: false,
        });
      },

      openConversation: (id) => {
        set({ currentId: id, panel: null, sidebarOpen: false });
      },

      deleteConversation: (id) => {
        const { conversations, currentId, userName, language } = get();
        const next = conversations.filter((c) => c.id !== id);
        if (next.length === 0) {
          const conv = blankConversation(userName || "AEGIS", language);
          set({ conversations: [conv], currentId: conv.id });
          return;
        }
        set({
          conversations: next,
          currentId: currentId === id ? next[0].id : currentId,
        });
      },

      clearHistory: () => {
        const { userName, language } = get();
        const conv = blankConversation(userName || "AEGIS", language);
        set({ conversations: [conv], currentId: conv.id, feedback: {} });
      },

      addMemoryNote: (note) => {
        const cleaned = note.trim().slice(0, LIMITS.memoryNoteLength);
        if (!cleaned) return;
        const { memory } = get();
        const notes = [cleaned, ...memory.notes.filter((n) => n !== cleaned)].slice(
          0,
          LIMITS.memoryNotes,
        );
        set({ memory: { ...memory, notes } });
      },

      removeMemoryNote: (index) => {
        const { memory } = get();
        set({ memory: { ...memory, notes: memory.notes.filter((_, i) => i !== index) } });
      },

      clearMemory: () => {
        const { memory } = get();
        set({ memory: { userName: memory.userName, notes: [], recentTopics: [] } });
      },

      clearAllData: () => {
        try {
          sessionStorage.removeItem(STORAGE_KEYS.session);
          localStorage.removeItem(STORAGE_KEYS.state);
        } catch {
          /* ignore */
        }
        set({
          language: "pt",
          theme: "dark",
          animations: true,
          voiceEnabled: true,
          autoSpeak: false,
          responseMode: "balanced",
          userName: "",
          verified: false,
          panel: null,
          sidebarOpen: false,
          isProcessing: false,
          conversations: [],
          currentId: null,
          memory: emptyMemory,
          feedback: {},
        });
      },

      setFeedback: (id, value) => {
        const { feedback } = get();
        const next = { ...feedback };
        if (next[id] === value) delete next[id];
        else next[id] = value;
        set({ feedback: next });
      },

      appendMessage: (message) => {
        const { conversations, currentId } = get();
        const id = currentId ?? conversations[0]?.id;
        if (!id) return;
        set({
          conversations: conversations.map((c) => {
            if (c.id !== id) return c;
            const messages = [...c.messages, message].slice(-LIMITS.messagesPerConversation);
            const title =
              c.messages.filter((m) => m.role === "user").length === 0 && message.role === "user"
                ? message.content.replace(/\s+/g, " ").trim().slice(0, 48) || c.title
                : c.title;
            return { ...c, title, messages, updatedAt: Date.now() };
          }),
          currentId: id,
        });
      },

      removeLastAssistant: () => {
        const { conversations, currentId } = get();
        const conv = conversations.find((c) => c.id === currentId);
        if (!conv) return null;
        const last = [...conv.messages].reverse().find((m) => m.role === "assistant" && m.tool !== "local");
        if (!last) return null;
        set({
          conversations: conversations.map((c) =>
            c.id === conv.id ? { ...c, messages: c.messages.filter((m) => m.id !== last.id) } : c,
          ),
        });
        return last;
      },

      rememberTopic: (topic) => {
        const cleaned = topic.replace(/\s+/g, " ").trim().slice(0, 80);
        if (!cleaned) return;
        const { memory } = get();
        const recentTopics = [cleaned, ...memory.recentTopics.filter((x) => x !== cleaned)].slice(0, 8);
        set({ memory: { ...memory, recentTopics } });
      },
    }),
    {
      name: STORAGE_KEYS.state,
      storage: createJSONStorage(() => {
        if (typeof window === "undefined") {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return localStorage;
      }),
      partialize: (s) => ({
        language: s.language,
        theme: s.theme,
        animations: s.animations,
        voiceEnabled: s.voiceEnabled,
        autoSpeak: s.autoSpeak,
        userName: s.userName,
        conversations: s.conversations,
        currentId: s.currentId,
        memory: s.memory,
        feedback: s.feedback,
      }),
    },
  ),
);

export function currentConversation(state: AegisState): Conversation | undefined {
  return state.conversations.find((c) => c.id === state.currentId) ?? state.conversations[0];
}
