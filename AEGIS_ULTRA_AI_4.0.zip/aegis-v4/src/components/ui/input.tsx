import type { InputHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "h-11 w-full rounded-md border border-line bg-elevated px-3 text-sm text-ink outline-none placeholder:text-subtle",
        "focus-visible:ring-2 focus-visible:ring-ring/70 focus-visible:border-line-strong",
        "disabled:opacity-40",
        className,
      )}
      {...props}
    />
  );
}
