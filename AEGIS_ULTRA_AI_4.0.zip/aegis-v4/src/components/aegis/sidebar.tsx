import {
  Brain,
  HelpCircle,
  History,
  MessageSquarePlus,
  Settings,
  Wrench,
  X,
} from "lucide-react";
import { t } from "@/lib/aegis/i18n";
import { useAegisStore } from "@/lib/aegis/store";
import type { PanelId } from "@/lib/aegis/types";
import { AegisMark } from "./mark";

export function Sidebar({ mobile = false }: { mobile?: boolean }) {
  const language = useAegisStore((s) => s.language);
  const panel = useAegisStore((s) => s.panel);
  const setPanel = useAegisStore((s) => s.setPanel);
  const newChat = useAegisStore((s) => s.newChat);
  const setSidebarOpen = useAegisStore((s) => s.setSidebarOpen);
  const userName = useAegisStore((s) => s.userName);
  const ui = t(language);

  function go(id: PanelId) {
    setPanel(panel === id ? null : id);
  }

  return (
    <div className="flex h-full flex-col bg-surface">
      <div className="flex items-center gap-3 border-b border-line px-4 py-4">
        <AegisMark className="size-7" />
        <div className="min-w-0 flex-1">
          <p className="truncate font-display text-lg leading-none tracking-tight">{ui.appName}</p>
          <p className="mt-1 text-[11px] uppercase tracking-[0.16em] text-subtle">{ui.version}</p>
        </div>
        {mobile ? (
          <button
            type="button"
            className="msg-action"
            aria-label={ui.close}
            onClick={() => setSidebarOpen(false)}
          >
            <X className="size-4" />
          </button>
        ) : null}
      </div>

      <div className="p-3">
        <button
          type="button"
          onClick={() => newChat()}
          className="flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-accent text-sm font-medium text-accent-fg transition-[scale,opacity] duration-150 ease-out active:scale-[0.96]"
        >
          <MessageSquarePlus className="size-4" />
          {ui.newChat}
        </button>
      </div>

      <nav className="flex flex-1 flex-col gap-0.5 px-2" aria-label={ui.appName}>
        <NavBtn active={panel === "history"} onClick={() => go("history")} icon={History} label={ui.history} />
        <NavBtn active={panel === "memory"} onClick={() => go("memory")} icon={Brain} label={ui.memory} />
        <NavBtn active={panel === "tools"} onClick={() => go("tools")} icon={Wrench} label={ui.tools} />
        <NavBtn active={panel === "settings"} onClick={() => go("settings")} icon={Settings} label={ui.settings} />
        <NavBtn active={panel === "help"} onClick={() => go("help")} icon={HelpCircle} label={ui.help} />
      </nav>

      <div className="border-t border-line px-4 py-4">
        <p className="truncate text-sm font-medium text-ink">{userName || "AEGIS"}</p>
        <p className="mt-0.5 text-xs text-subtle">{ui.brand}</p>
      </div>
    </div>
  );
}

function NavBtn({
  active,
  onClick,
  icon: Icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: typeof History;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={`flex h-11 items-center gap-3 rounded-lg px-3 text-sm transition-[background-color,color] duration-150 ${
        active ? "bg-elevated text-ink" : "text-muted hover:bg-elevated/70 hover:text-ink"
      }`}
    >
      <Icon className="size-4 shrink-0" />
      {label}
    </button>
  );
}
