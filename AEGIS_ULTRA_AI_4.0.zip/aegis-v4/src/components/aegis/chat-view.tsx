import { useEffect, useRef } from "react";
import { t } from "@/lib/aegis/i18n";
import { currentConversation, useAegisStore } from "@/lib/aegis/store";
import { useChat } from "@/lib/aegis/use-chat";
import { Composer } from "./composer";
import { AegisMark } from "./mark";
import { MessageBubble } from "./message-bubble";

export function ChatView() {
  const language = useAegisStore((s) => s.language);
  const conv = useAegisStore((s) => currentConversation(s));
  const isProcessing = useAegisStore((s) => s.isProcessing);
  const { send, regenerate } = useChat();
  const ui = t(language);
  const endRef = useRef<HTMLDivElement>(null);
  const scrollerRef = useRef<HTMLDivElement>(null);

  const messages = conv?.messages ?? [];
  const lastAssistant = [...messages].reverse().find((m) => m.role === "assistant");
  const hasUser = messages.some((m) => m.role === "user");

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, isProcessing]);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div ref={scrollerRef} className="min-h-0 flex-1 overflow-y-auto px-4 py-6 sm:px-6">
        <div className="mx-auto flex max-w-3xl flex-col gap-6">
          {!hasUser ? (
            <div className="flex flex-col items-center px-2 pb-6 pt-8 text-center">
              <AegisMark className="mb-5 size-10 text-muted" />
              <h1 className="font-display text-3xl tracking-tight text-ink">{ui.emptyTitle}</h1>
              <p className="mt-2 max-w-md text-sm leading-relaxed text-muted text-pretty">{ui.emptyLead}</p>
              <div className="mt-6 flex w-full max-w-lg flex-col gap-2">
                {[ui.suggestion1, ui.suggestion2, ui.suggestion3].map((s) => (
                  <button
                    key={s}
                    type="button"
                    className="rounded-xl border border-line bg-surface px-4 py-3 text-left text-sm text-ink transition-[background-color] duration-150 hover:bg-elevated"
                    onClick={() => void send(s)}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : null}

          {messages.map((m, idx) => (
            <MessageBubble
              key={m.id}
              message={m}
              onRegenerate={
                !isProcessing && m.id === lastAssistant?.id && m.tool !== "local" && hasUser
                  ? () => void regenerate()
                  : undefined
              }
            />
          ))}

          {isProcessing ? (
            <p className="shimmer-text pl-11 text-sm text-muted" aria-live="polite">
              {ui.processing}
            </p>
          ) : null}
          <div ref={endRef} />
        </div>
      </div>
      <Composer />
    </div>
  );
}
