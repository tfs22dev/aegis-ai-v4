import { useState, type ReactNode } from "react";
import { Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { t } from "@/lib/aegis/i18n";
import { formatDateTime } from "@/lib/utils";
import { useAegisStore } from "@/lib/aegis/store";
import type { PanelId } from "@/lib/aegis/types";

export function SlideOver({
  title,
  children,
  onClose,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
}) {
  return (
    <aside
      className="panel-enter absolute inset-y-0 right-0 z-30 flex w-full max-w-md flex-col border-l border-line bg-surface shadow-border sm:w-[24rem]"
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      <header className="flex items-center justify-between gap-3 border-b border-line px-4 py-3">
        <h2 className="font-display text-xl tracking-tight text-ink">{title}</h2>
        <button type="button" className="msg-action" aria-label={t(useAegisStore.getState().language).close} onClick={onClose}>
          <X className="size-4" />
        </button>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto p-4">{children}</div>
    </aside>
  );
}

export function PanelHost() {
  const panel = useAegisStore((s) => s.panel);
  const setPanel = useAegisStore((s) => s.setPanel);
  const language = useAegisStore((s) => s.language);
  const ui = t(language);
  if (!panel) return null;
  const titles: Record<PanelId, string> = {
    history: ui.history,
    memory: ui.memory,
    tools: ui.tools,
    settings: ui.settings,
    help: ui.help,
  };
  return (
    <>
      <button
        type="button"
        className="absolute inset-0 z-20 bg-canvas/40"
        aria-label={ui.close}
        onClick={() => setPanel(null)}
      />
      <SlideOver title={titles[panel]} onClose={() => setPanel(null)}>
        {panel === "history" ? <HistoryPanel /> : null}
        {panel === "memory" ? <MemoryPanel /> : null}
        {panel === "tools" ? <ToolsPanel /> : null}
        {panel === "settings" ? <SettingsPanel /> : null}
        {panel === "help" ? <HelpPanel /> : null}
      </SlideOver>
    </>
  );
}

function HistoryPanel() {
  const language = useAegisStore((s) => s.language);
  const conversations = useAegisStore((s) => s.conversations);
  const currentId = useAegisStore((s) => s.currentId);
  const openConversation = useAegisStore((s) => s.openConversation);
  const deleteConversation = useAegisStore((s) => s.deleteConversation);
  const ui = t(language);
  if (!conversations.length) {
    return <p className="text-sm text-muted">{ui.historyEmpty}</p>;
  }
  return (
    <ul className="space-y-1">
      {conversations.map((c) => (
        <li key={c.id} className="flex items-center gap-1 rounded-lg hover:bg-elevated">
          <button
            type="button"
            onClick={() => openConversation(c.id)}
            className={`min-w-0 flex-1 rounded-lg px-3 py-2.5 text-left ${
              c.id === currentId ? "text-ink" : "text-muted"
            }`}
          >
            <p className="truncate text-sm font-medium text-ink">{c.title}</p>
            <p className="text-[11px] text-subtle">{formatDateTime(c.updatedAt, language)}</p>
          </button>
          <button
            type="button"
            className="msg-action mr-1"
            aria-label={ui.historyDelete}
            onClick={() => {
              deleteConversation(c.id);
              toast.success(ui.deleted);
            }}
          >
            <Trash2 className="size-3.5" />
          </button>
        </li>
      ))}
    </ul>
  );
}

function MemoryPanel() {
  const language = useAegisStore((s) => s.language);
  const memory = useAegisStore((s) => s.memory);
  const userName = useAegisStore((s) => s.userName);
  const addMemoryNote = useAegisStore((s) => s.addMemoryNote);
  const removeMemoryNote = useAegisStore((s) => s.removeMemoryNote);
  const clearMemory = useAegisStore((s) => s.clearMemory);
  const [note, setNote] = useState("");
  const [confirm, setConfirm] = useState(false);
  const ui = t(language);

  return (
    <div className="space-y-6">
      <p className="text-sm leading-relaxed text-muted text-pretty">{ui.memoryLead}</p>
      <dl className="space-y-3 text-sm">
        <div>
          <dt className="text-xs uppercase tracking-wider text-subtle">{ui.memoryName}</dt>
          <dd className="mt-1 text-ink">{userName || "—"}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wider text-subtle">{ui.memoryLanguage}</dt>
          <dd className="mt-1 text-ink">{language === "pt" ? ui.portuguese : ui.english}</dd>
        </div>
      </dl>
      <section>
        <h3 className="text-xs uppercase tracking-wider text-subtle">{ui.memoryNotes}</h3>
        <form
          className="mt-2 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            addMemoryNote(note);
            setNote("");
            toast.success(ui.memorySaved);
          }}
        >
          <Input
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder={ui.memoryAddPlaceholder}
            maxLength={240}
          />
          <Button type="submit" size="sm" className="shrink-0">
            {ui.memoryAdd}
          </Button>
        </form>
        {memory.notes.length === 0 ? (
          <p className="mt-3 text-sm text-muted">{ui.memoryNotesEmpty}</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {memory.notes.map((n, i) => (
              <li key={`${n}-${i}`} className="flex items-start gap-2 rounded-lg bg-elevated px-3 py-2 text-sm">
                <span className="flex-1 text-pretty">{n}</span>
                <button type="button" className="msg-action" aria-label={ui.close} onClick={() => removeMemoryNote(i)}>
                  <X className="size-3.5" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>
      <section>
        <h3 className="text-xs uppercase tracking-wider text-subtle">{ui.memoryTopics}</h3>
        {memory.recentTopics.length === 0 ? (
          <p className="mt-2 text-sm text-muted">{ui.memoryTopicsEmpty}</p>
        ) : (
          <ul className="mt-2 flex flex-wrap gap-2">
            {memory.recentTopics.map((topic) => (
              <li key={topic} className="rounded-full border border-line px-3 py-1 text-xs text-muted">
                {topic}
              </li>
            ))}
          </ul>
        )}
      </section>
      {confirm ? (
        <div className="rounded-xl border border-line p-3">
          <p className="text-sm text-ink">{ui.memoryClearConfirm}</p>
          <div className="mt-3 flex gap-2">
            <Button variant="danger" size="sm" onClick={() => { clearMemory(); setConfirm(false); }}>
              {ui.confirm}
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setConfirm(false)}>
              {ui.cancel}
            </Button>
          </div>
        </div>
      ) : (
        <Button variant="outline" onClick={() => setConfirm(true)}>
          {ui.memoryClear}
        </Button>
      )}
    </div>
  );
}

function ToolsPanel() {
  const language = useAegisStore((s) => s.language);
  const modelAvailable = useAegisStore((s) => s.modelAvailable);
  const ui = t(language);
  const items = [
    [ui.toolCalc, ui.toolCalcDesc],
    [ui.toolWiki, ui.toolWikiDesc],
    [ui.toolSearch, ui.toolSearchDesc],
    [ui.toolImages, ui.toolImagesDesc],
    [ui.toolVoice, ui.toolVoiceDesc],
    [ui.toolModel, modelAvailable ? ui.toolModelDescOn : ui.toolModelDescOff],
  ];
  return (
    <div className="space-y-4">
      <p className="text-sm leading-relaxed text-muted text-pretty">{ui.toolsLead}</p>
      <ul className="space-y-3">
        {items.map(([title, desc]) => (
          <li key={title} className="rounded-xl border border-line px-3 py-3">
            <p className="text-sm font-medium text-ink">{title}</p>
            <p className="mt-1 text-sm text-muted text-pretty">{desc}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

function SettingsPanel() {
  const language = useAegisStore((s) => s.language);
  const theme = useAegisStore((s) => s.theme);
  const animations = useAegisStore((s) => s.animations);
  const voiceEnabled = useAegisStore((s) => s.voiceEnabled);
  const autoSpeak = useAegisStore((s) => s.autoSpeak);
  const responseMode = useAegisStore((s) => s.responseMode);
  const setLanguage = useAegisStore((s) => s.setLanguage);
  const setTheme = useAegisStore((s) => s.setTheme);
  const setAnimations = useAegisStore((s) => s.setAnimations);
  const setVoiceEnabled = useAegisStore((s) => s.setVoiceEnabled);
  const setAutoSpeak = useAegisStore((s) => s.setAutoSpeak);
  const setResponseMode = useAegisStore((s) => s.setResponseMode);
  const clearHistory = useAegisStore((s) => s.clearHistory);
  const clearAllData = useAegisStore((s) => s.clearAllData);
  const ui = t(language);
  const [which, setWhich] = useState<null | "history" | "all">(null);

  return (
    <div className="space-y-8">
      <section>
        <h3 className="text-xs uppercase tracking-wider text-subtle">{ui.settingsInterface}</h3>
        <div className="mt-3 space-y-4">
          <Row label={ui.settingsLanguage}>
            <div className="flex rounded-md border border-line p-0.5">
              <button
                type="button"
                className={`h-8 px-3 text-xs font-medium ${language === "pt" ? "rounded-sm bg-elevated text-ink" : "text-muted"}`}
                onClick={() => setLanguage("pt")}
              >
                PT
              </button>
              <button
                type="button"
                className={`h-8 px-3 text-xs font-medium ${language === "en" ? "rounded-sm bg-elevated text-ink" : "text-muted"}`}
                onClick={() => setLanguage("en")}
              >
                EN
              </button>
            </div>
          </Row>
          <Row label={ui.settingsTheme}>
            <Switch
              checked={theme === "dark"}
              onCheckedChange={(v) => setTheme(v ? "dark" : "light")}
              aria-label={ui.settingsTheme}
            />
          </Row>
          <Row label={ui.settingsMotion}>
            <Switch checked={animations} onCheckedChange={setAnimations} aria-label={ui.settingsMotion} />
          </Row>
        </div>
      </section>
      <section>
        <h3 className="text-xs uppercase tracking-wider text-subtle">{ui.settingsAi}</h3>
        <div className="mt-3 space-y-4">
          <div>
            <p className="text-sm text-ink mb-2">{ui.responseMode}</p>
            <div className="flex flex-wrap gap-1.5">
              {(
                [
                  ["fast", ui.responseModeFast, ui.responseModeFastDesc],
                  ["balanced", ui.responseModeBalanced, ui.responseModeBalancedDesc],
                  ["deep", ui.responseModeDeep, ui.responseModeDeepDesc],
                ] as const
              ).map(([mode, label, desc]) => (
                <button
                  key={mode}
                  type="button"
                  title={desc}
                  className={`h-9 rounded-md px-3 text-xs font-medium transition ${
                    responseMode === mode
                      ? "bg-accent text-accent-fg"
                      : "border border-line text-muted hover:text-ink"
                  }`}
                  onClick={() => setResponseMode(mode)}
                >
                  {label}
                </button>
              ))}
            </div>
            <p className="mt-1.5 text-xs text-subtle">
              {responseMode === "fast"
                ? ui.responseModeFastDesc
                : responseMode === "deep"
                  ? ui.responseModeDeepDesc
                  : ui.responseModeBalancedDesc}
            </p>
          </div>
          <Row label={ui.settingsVoice}>
            <Switch checked={voiceEnabled} onCheckedChange={setVoiceEnabled} aria-label={ui.settingsVoice} />
          </Row>
          <Row label={ui.settingsAutoSpeak}>
            <Switch
              checked={autoSpeak && voiceEnabled}
              disabled={!voiceEnabled}
              onCheckedChange={setAutoSpeak}
              aria-label={ui.settingsAutoSpeak}
            />
          </Row>
        </div>
      </section>
      <section>
        <h3 className="text-xs uppercase tracking-wider text-subtle">{ui.settingsData}</h3>
        <div className="mt-3 flex flex-col gap-2">
          <Button variant="outline" onClick={() => setWhich("history")}>
            {ui.settingsClearHistory}
          </Button>
          <Button variant="outline" onClick={() => setWhich("all")}>
            {ui.settingsClearAll}
          </Button>
        </div>
        {which ? (
          <div className="mt-3 rounded-xl border border-line p-3">
            <p className="text-sm text-ink">
              {which === "history" ? ui.settingsClearHistoryConfirm : ui.settingsClearAllConfirm}
            </p>
            <div className="mt-3 flex gap-2">
              <Button
                variant="danger"
                size="sm"
                onClick={() => {
                  if (which === "history") clearHistory();
                  else {
                    clearAllData();
                    toast.success(ui.dataCleared);
                  }
                  setWhich(null);
                }}
              >
                {ui.confirm}
              </Button>
              <Button variant="ghost" size="sm" onClick={() => setWhich(null)}>
                {ui.cancel}
              </Button>
            </div>
          </div>
        ) : null}
      </section>
      <section>
        <h3 className="text-xs uppercase tracking-wider text-subtle">{ui.settingsAbout}</h3>
        <p className="mt-2 font-display text-2xl tracking-tight">{ui.appName}</p>
        <p className="text-sm text-muted">{ui.version}</p>
        <p className="mt-3 text-sm leading-relaxed text-muted text-pretty">{ui.aboutBody}</p>
      </section>
    </div>
  );
}

function HelpPanel() {
  const language = useAegisStore((s) => s.language);
  const ui = t(language);
  const blocks = [
    [ui.helpChat, ui.helpChatBody],
    [ui.helpVoice, ui.helpVoiceBody],
    [ui.helpMemory, ui.helpMemoryBody],
    [ui.helpTools, ui.helpToolsBody],
    [ui.helpEmbed, ui.helpEmbedBody],
  ];
  return (
    <div className="space-y-5">
      <div>
        <h3 className="font-display text-2xl tracking-tight">{ui.helpTitle}</h3>
        <p className="mt-2 text-sm leading-relaxed text-muted text-pretty">{ui.helpIntro}</p>
      </div>
      {blocks.map(([title, body]) => (
        <section key={title}>
          <h4 className="text-sm font-medium text-ink">{title}</h4>
          <p className="mt-1 text-sm leading-relaxed text-muted text-pretty">{body}</p>
        </section>
      ))}
      <p className="text-xs leading-relaxed text-subtle text-pretty">{ui.helpPrivacy}</p>
    </div>
  );
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-sm text-ink">{label}</span>
      {children}
    </div>
  );
}
