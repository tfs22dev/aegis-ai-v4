import { cn } from "@/lib/utils";

export function AegisMark({ className, title = "AEGIS ULTRA AI" }: { className?: string; title?: string }) {
  return (
    <img
      src="/aegis-logo.jpeg"
      alt={title}
      className={cn("object-contain", className)}
      width={40}
      height={40}
      decoding="async"
    />
  );
}
