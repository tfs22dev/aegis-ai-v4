import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { AppShell } from "@/components/aegis/app-shell";
import { GateScreen } from "@/components/aegis/gate-screen";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAegisStore } from "@/lib/aegis/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const hydrated = useAegisStore((s) => s.hydrated);
  const verified = useAegisStore((s) => s.verified);
  const language = useAegisStore((s) => s.language);
  const theme = useAegisStore((s) => s.theme);
  const animations = useAegisStore((s) => s.animations);
  const markHydrated = useAegisStore((s) => s.markHydrated);

  useEffect(() => {
    const finish = () => markHydrated();
    const unsub = useAegisStore.persist.onFinishHydration(finish);
    if (useAegisStore.persist.hasHydrated()) finish();
    return unsub;
  }, [markHydrated]);

  useEffect(() => {
    document.documentElement.lang = language === "pt" ? "pt" : "en";
    document.documentElement.dataset.theme = theme;
    document.documentElement.classList.toggle("motion-off", !animations);
  }, [language, theme, animations]);

  return (
    <TooltipProvider>
      <Toaster
        theme={theme === "dark" ? "dark" : "light"}
        position="bottom-center"
        toastOptions={{
          className: "bg-elevated text-ink border border-line text-sm",
        }}
      />
      {!hydrated || !verified ? <GateScreen /> : <AppShell />}
    </TooltipProvider>
  );
}
